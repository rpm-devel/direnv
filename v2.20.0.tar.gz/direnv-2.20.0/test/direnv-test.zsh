#!/usr/bin/env zsh
export TARGET_SHELL=zsh
source "$(dirname $0)/direnv-test-common.sh"
