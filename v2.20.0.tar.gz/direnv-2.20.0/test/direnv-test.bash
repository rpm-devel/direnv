#!/usr/bin/env bash
export TARGET_SHELL=bash
source "$(dirname $0)/direnv-test-common.sh"
