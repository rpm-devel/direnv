## Issue description

### Steps to reproduce

## Technical details

<!-- to better help you, please provide the following information: -->

* target shell:
* `direnv version`:
* OS release: (eg: Ubuntu 16.04)
